# SQL Shield: SQL Injection and Data-Leak Protection

A beginner-friendly Python/Flask demonstration of layered protection against SQL injection and unauthorized access.

## Features

- **SQL injection prevention:** all database values are passed through parameterized SQLite queries.
- **AES-256-GCM encryption:** sensitive note content is encrypted before it is stored in the database. GCM also detects tampering.
- **Capability-code gate:** users must enter a server-side access code before viewing or saving notes.
- **Basic web security headers:** includes CSP, `X-Frame-Options`, `X-Content-Type-Options`, and a referrer policy.
- **Cloud-ready:** can run on a Python hosting service; SQLite is suitable for a demo, not every multi-instance production deployment.
- **Health endpoint:** `GET /health` returns a small status response.

## How the double-layer protection works

1. **Input/database layer:** SQL uses placeholders (`?`) and bound parameters. User input is treated as data, not SQL code.
2. **Data/access layer:** a capability code gates the notes interface, and note contents are encrypted using AES-256-GCM before being written to the database.

These controls complement one another. Encryption alone does not prevent SQL injection, and parameterized SQL alone does not encrypt data at rest.

## Files

- `app.py` — Flask application and database logic
- `requirements.txt` — Python dependencies
- `.env.example` — names of required environment variables (no real secrets)
- `.gitignore` — excludes local secrets and database files

## Run locally

Python 3.10+ is recommended.

### 1. Create a virtual environment (optional but recommended)

```bash
python -m venv .venv
```

Activate it:

- Windows: `.venv\Scripts\activate`
- macOS/Linux: `source .venv/bin/activate`

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Generate secure environment values

Run this command in a terminal to print a random Flask secret, an AES-256 key encoded as URL-safe Base64, and a random capability code:

```bash
python -c "import secrets,base64; print('FLASK_SECRET_KEY='+secrets.token_urlsafe(48)); print('AES_256_KEY='+base64.urlsafe_b64encode(secrets.token_bytes(32)).decode()); print('CAPABILITY_CODE='+secrets.token_urlsafe(24))"
```

Copy the three generated values into your terminal environment or your hosting provider's secret settings. Do **not** commit them to GitHub.

Example for macOS/Linux:

```bash
export FLASK_SECRET_KEY='paste-generated-value'
export AES_256_KEY='paste-generated-value'
export CAPABILITY_CODE='paste-generated-value'
```

PowerShell example:

```powershell
$env:FLASK_SECRET_KEY="paste-generated-value"
$env:AES_256_KEY="paste-generated-value"
$env:CAPABILITY_CODE="paste-generated-value"
```

### 4. Start the app

```bash
python app.py
```

Open `http://127.0.0.1:5000` in your browser. Enter the capability code generated above.

## Deploy to the cloud

1. Push this project to a GitHub repository.
2. Create a Python web service on a hosting provider that supports Flask/Gunicorn.
3. Set the build command to `pip install -r requirements.txt`.
4. Set the start command to `gunicorn app:app`.
5. Add `FLASK_SECRET_KEY`, `AES_256_KEY`, and `CAPABILITY_CODE` as **private environment variables** in the hosting dashboard.
6. Set `COOKIE_SECURE=1` when HTTPS is enabled.
7. Attach persistent storage and set `DATABASE_PATH` to a path on that storage if the host's filesystem is temporary.

Hosting provider free tiers and persistent disk availability can change. Check the provider's current limits before deploying.

## Test the SQL injection defense

1. Unlock the app.
2. Save a note with a label such as `demo`.
3. Search for `demo` and confirm that it appears.
4. Search for this harmless test string:

   ```text
   ' OR '1'='1
   ```

   It should be treated as ordinary search text, not as executable SQL. The app should not suddenly return every record.

This is a defensive demonstration. Test only systems you own or have permission to assess.

## Security limitations — read before real use

This is an educational prototype, not a production-ready secrets manager.

- The capability code is a shared demo credential, not individual user authentication. Add proper accounts, password hashing, rate limiting, lockout controls, and audit logging before real use.
- Use HTTPS in deployment. Never commit secrets, encryption keys, `.env` files, or `app.db`.
- Back up the AES key securely. If it is lost, encrypted note contents cannot be recovered; if it is exposed, stored notes may be exposed.
- Keep the encryption key separate from the database and rotate it with a planned migration process.
- Labels and timestamps are not encrypted in this demo; only note content is encrypted.
- SQLite can be unsuitable for multiple app instances and concurrent production traffic. Use a managed database with appropriate access controls for a real multi-instance deployment.
- Do not store actual account passwords as reversible encrypted notes. For user login passwords, use a password-hashing algorithm such as Argon2id or scrypt.
- Add CSRF protection, rate limiting, proper user identity and authorization, monitoring, and security testing before handling real data.
- `debug=False` is set. Do not enable Flask debug mode on a public server.

## License

Use and modify this educational project for learning. Add a license file if you plan to distribute it publicly.
