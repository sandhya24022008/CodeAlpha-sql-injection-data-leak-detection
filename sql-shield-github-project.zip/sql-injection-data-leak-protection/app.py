import os
import base64
import hmac
import secrets
import sqlite3
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from flask import Flask, abort, flash, redirect, render_template_string, request, session, url_for

APP_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("DATABASE_PATH", APP_DIR / "app.db"))
SECRET_KEY = os.environ.get("FLASK_SECRET_KEY")
AES_KEY_B64 = os.environ.get("AES_256_KEY")
ACCESS_CODE = os.environ.get("CAPABILITY_CODE")

if not SECRET_KEY or not AES_KEY_B64 or not ACCESS_CODE:
    raise RuntimeError(
        "Set FLASK_SECRET_KEY, AES_256_KEY, and CAPABILITY_CODE environment variables. "
        "See README.md for setup."
    )

try:
    AES_KEY = base64.urlsafe_b64decode(AES_KEY_B64.encode("ascii"))
except Exception as exc:
    raise RuntimeError("AES_256_KEY must be URL-safe Base64 for a 32-byte key.") from exc

if len(AES_KEY) != 32:
    raise RuntimeError("AES_256_KEY must decode to exactly 32 bytes (AES-256).")

app = Flask(__name__)
app.secret_key = SECRET_KEY
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    # Enable this in production behind HTTPS.
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1",
    MAX_CONTENT_LENGTH=16 * 1024,
)


def get_db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def init_db():
    with get_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS protected_notes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                label TEXT NOT NULL,
                nonce BLOB NOT NULL,
                ciphertext BLOB NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)


def encrypt_text(plaintext: str):
    """AES-256-GCM: authenticated encryption with a fresh 96-bit nonce."""
    nonce = secrets.token_bytes(12)
    ciphertext = AESGCM(AES_KEY).encrypt(nonce, plaintext.encode("utf-8"), None)
    return nonce, ciphertext


def decrypt_text(nonce: bytes, ciphertext: bytes):
    return AESGCM(AES_KEY).decrypt(nonce, ciphertext, None).decode("utf-8")


PAGE = """
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SQL Shield Demo</title>
  <style>
    :root { color-scheme: light dark; --accent:#3b82f6; }
    * { box-sizing:border-box; }
    body { margin:0; font-family:system-ui, sans-serif; background:Canvas; color:CanvasText; }
    main { width:min(760px, 92%); margin:32px auto; }
    header, section { border:1px solid color-mix(in srgb, CanvasText 18%, transparent);
      border-radius:16px; padding:20px; margin-bottom:16px; }
    h1 { margin:0 0 8px; font-size:1.7rem; }
    .muted { opacity:.75; }
    label { display:block; margin:12px 0 6px; font-weight:600; }
    input, textarea, button { width:100%; padding:12px; border-radius:10px;
      border:1px solid color-mix(in srgb, CanvasText 25%, transparent); font:inherit; }
    textarea { min-height:100px; resize:vertical; }
    button { margin-top:12px; background:var(--accent); color:white; border:0; font-weight:700; }
    .note { border-top:1px solid color-mix(in srgb, CanvasText 18%, transparent); padding:12px 0; }
    .message { padding:10px; border-radius:8px; background:color-mix(in srgb, var(--accent) 15%, transparent); }
    code { overflow-wrap:anywhere; }
  </style>
</head>
<body><main>
  <header>
    <h1>SQL Shield</h1>
    <p class="muted">Learning demo: parameterized SQL + AES-256-GCM + capability-code access.</p>
    <p><strong>Security layers:</strong> SQL injection prevention · encrypted stored content · protected access</p>
    {% if unlocked %}
      <form method="post" action="{{ url_for('lock') }}"><button type="submit">Lock session</button></form>
    {% endif %}
  </header>

  {% with messages = get_flashed_messages() %}
    {% if messages %}{% for message in messages %}<p class="message">{{ message }}</p>{% endfor %}{% endif %}
  {% endwith %}

  {% if not unlocked %}
    <section>
      <h2>Enter capability code</h2>
      <p class="muted">The server checks the code before showing or storing protected notes.</p>
      <form method="post" action="{{ url_for('unlock') }}">
        <label for="code">Capability code</label>
        <input id="code" name="code" type="password" required maxlength="128" autocomplete="off">
        <button type="submit">Unlock</button>
      </form>
    </section>
  {% else %}
    <section>
      <h2>Store an encrypted note</h2>
      <form method="post" action="{{ url_for('add_note') }}">
        <label for="label">Label (not encrypted)</label>
        <input id="label" name="label" required maxlength="80">
        <label for="secret">Sensitive note (encrypted before database storage)</label>
        <textarea id="secret" name="secret" required maxlength="4000"></textarea>
        <button type="submit">Encrypt and save</button>
      </form>
    </section>
    <section>
      <h2>Search saved notes</h2>
      <form method="get" action="{{ url_for('home') }}">
        <label for="q">Search labels</label>
        <input id="q" name="q" maxlength="80" value="{{ query }}">
        <button type="submit">Search</button>
      </form>
      <p class="muted">Search uses a parameterized SQL query. Try a test string such as <code>' OR '1'='1</code>; it is treated as ordinary text.</p>
      {% if notes %}
        {% for note in notes %}
          <div class="note">
            <strong>{{ note.label }}</strong>
            <p>{{ note.secret }}</p>
            <small class="muted">Created: {{ note.created_at }}</small>
          </div>
        {% endfor %}
      {% else %}
        <p class="muted">No matching notes yet.</p>
      {% endif %}
    </section>
  {% endif %}
  <p class="muted">Demo only. Do not store real passwords, payment data, or production secrets in this sample.</p>
</main></body></html>
"""


def is_unlocked():
    return session.get("unlocked") is True


@app.after_request
def security_headers(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'"
    return response


@app.get("/")
def home():
    unlocked = is_unlocked()
    notes = []
    query = request.args.get("q", "")[:80]
    if unlocked:
        # Parameterized query: user input is a value, never executable SQL.
        with get_db() as db:
            rows = db.execute(
                "SELECT id, label, nonce, ciphertext, created_at "
                "FROM protected_notes WHERE label LIKE ? ORDER BY id DESC LIMIT 100",
                (f"%{query}%",),
            ).fetchall()
        for row in rows:
            try:
                secret = decrypt_text(row["nonce"], row["ciphertext"])
            except Exception:
                secret = "[Unable to decrypt: key may be incorrect or data may be damaged]"
            notes.append({"label": row["label"], "secret": secret, "created_at": row["created_at"]})
    return render_template_string(PAGE, unlocked=unlocked, notes=notes, query=query)


@app.post("/unlock")
def unlock():
    submitted = request.form.get("code", "")
    if hmac.compare_digest(submitted, ACCESS_CODE):
        session.clear()
        session["unlocked"] = True
        session.permanent = False
        return redirect(url_for("home"))
    # Avoid telling a user which part of the credential was wrong.
    flash("Access denied. Check the capability code and try again.")
    return redirect(url_for("home"))


@app.post("/lock")
def lock():
    session.clear()
    return redirect(url_for("home"))


@app.post("/notes")
def add_note():
    if not is_unlocked():
        abort(403)
    label = request.form.get("label", "").strip()
    secret = request.form.get("secret", "").strip()
    if not label or not secret or len(label) > 80 or len(secret) > 4000:
        flash("Enter a label and a note within the allowed length.")
        return redirect(url_for("home"))
    nonce, ciphertext = encrypt_text(secret)
    # Both values are bound parameters; no string concatenation of SQL.
    with get_db() as db:
        db.execute(
            "INSERT INTO protected_notes (label, nonce, ciphertext) VALUES (?, ?, ?)",
            (label, nonce, ciphertext),
        )
    flash("Note encrypted and saved.")
    return redirect(url_for("home"))


@app.get("/health")
def health():
    return {"status": "ok"}


init_db()

if __name__ == "__main__":
    # Local development only. Use Gunicorn or a platform process command in production.
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=False)
